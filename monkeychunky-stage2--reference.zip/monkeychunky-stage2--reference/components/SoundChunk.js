import * as React from 'react';
import {Text, View, StyleSheet, TouchableOpacity} from 'react-native';
import {Audio} from 'expo-av';

export default class WordPhrase extends React.Component {
  playSound = async WordPhrase => {
    console.log(WordPhrase);
    var soundLink = 'https://whitehatjrcontent.s3.ap-south-1.amazonaws.com/phones/' +
    WordPhrase +
    '.mp3';
    await Audio.Sound.createAsync(
      {
        url: soundLink,

      },
      {shouldPlay: true}
    );
  };
  render() {
    return(
      <TouchableOpacity
      style = {styles.phraseButton}
      onPress = {() => {
        this.playSound(this.props.WordPhrase);

      }}>

      <Text style = {styles.displayText}>{this.props.WordPhrase}</Text>
      </TouchableOpacity>

    );
  }
}

const styles = StyleSheet.create({
  displayText: {
    textAlign: 'center',
    fontSize: 30,
    color: 'white' 
    },
    phraseButton: {
      width: '60%',
      height: 50,
      justifyContent: 'center',
      alignItems: 'center',
      alignSelf: 'center',
      BorderRadius: 10,
      margin: 5,
      backgroundColor: 'red'
    }
})
